# Saathi AI — "Your eyes, your companion"

English-only mobile web app: on-device object detection, live GPS, voice commands and obstacle alerts (simulated or ESP32 BLE sensor). Optional online scene description via Gemini, called **through the server** so the API key never reaches the browser.

> **Safety:** Experimental prototype, not a certified mobility aid. Never rely on it alone. The app never says the path is safe.

## Run locally
```bash
GEMINI_API_KEY=your_key npm start     # then open http://localhost:8080 in Chrome
```
Camera, mic and GPS need HTTPS or localhost.

## Deploy: GitHub + Railway
```bash
git init && git add . && git commit -m "Saathi AI"
git branch -M main
git remote add origin https://github.com/<you>/saathi-ai.git
git push -u origin main
```
1. Railway → **New Project → Deploy from GitHub repo** → pick `saathi-ai`.
2. Service → **Variables** → add `GEMINI_API_KEY` = your key (optional: `GEMINI_MODEL`).
3. Service → **Settings → Networking → Generate Domain**. Railway gives HTTPS, so camera/mic/GPS work on your phone.

If the key is missing, invalid, blocked or out of quota, the app shows a red banner and speaks the error. Never commit a key; `.env` is git-ignored.

## Layout
`server.js` static server + `/api/status` + `/api/describe` · `public/` the app (index.html, tests.html, css/, js/)

## Voice commands (push-to-talk, en-US)
"Start assistance" · "What's ahead?" · "My location" · "Sensor status" · "Camera on / off" · "Start navigation" · "Be quiet" · "Stop assistance"

## Detection
COCO-SSD `mobilenet_v2` (WebGL), 1280×720 camera, score ≥ 0.30 with temporal smoothing. Distance is an estimate (±30%); real distance needs the BLE ultrasonic sensor (service `0xFFE0`, characteristic `0xFFE1`, ASCII centimeters).
