// Saathi AI server: serves ./public and proxies Gemini so the API key stays in the environment.
// Required env var: GEMINI_API_KEY   (set it in Railway -> Variables)
// Optional: GEMINI_MODEL (default gemini-2.5-flash), PORT (set by Railway)
import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(fileURLToPath(new URL('.', import.meta.url)), 'public');
const KEY = (process.env.GEMINI_API_KEY || '').trim();
const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const API = 'https://generativelanguage.googleapis.com/v1beta/models';
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
const PROMPT = 'You are an assistant for a visually impaired person. Describe what is in this photo in 3-4 short, simple English sentences. Start with the nearest things. For each item say what it is, whether it is on the left, ahead or on the right, and roughly how many meters away. Mention hazards first (stairs, holes, vehicles, open doors, wet floor). If something is unclear, say so. Never say the path is safe.';

const hits = new Map(); // simple per-IP rate limit: 20 requests / minute
function limited(ip) {
  const now = Date.now(), list = (hits.get(ip) || []).filter(t => now - t < 60000);
  list.push(now); hits.set(ip, list); return list.length > 20;
}

function mapError(status, body) {
  const msg = (body?.error?.message || '').toLowerCase(), det = JSON.stringify(body?.error?.details || '');
  if (status === 400 && (msg.includes('api key') || det.includes('API_KEY_INVALID'))) return { code: 'invalid', message: 'The Gemini API key is invalid or has expired.' };
  if (status === 401 || status === 403) return { code: 'blocked', message: 'The Gemini API key is disabled, blocked or not allowed. Check it in Google AI Studio.' };
  if (status === 429) return { code: 'quota', message: 'The Gemini quota is used up. Please try again later.' };
  return { code: 'http', message: `Gemini returned an error (code ${status}).` };
}
const MISSING = { code: 'missing', message: 'Gemini API key is not set. Add GEMINI_API_KEY in the Railway Variables.' };

const CORS = { 'Access-Control-Allow-Origin': process.env.ALLOWED_ORIGIN || '*', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };
function send(res, status, obj) { res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...CORS }); res.end(JSON.stringify(obj)); }

async function status(res) {
  if (!KEY) return send(res, 503, { error: MISSING });
  try {
    const r = await fetch(`${API}?pageSize=1`, { headers: { 'x-goog-api-key': KEY } });
    if (r.ok) return send(res, 200, { ok: true });
    return send(res, 502, { error: mapError(r.status, await r.json().catch(() => null)) });
  } catch { return send(res, 502, { error: { code: 'network', message: 'Server could not reach Google.' } }); }
}

async function describe(req, res) {
  if (!KEY) return send(res, 503, { error: MISSING });
  let raw = ''; for await (const c of req) { raw += c; if (raw.length > 3e6) return send(res, 413, { error: { code: 'http', message: 'Image too large.' } }); }
  let image; try { image = JSON.parse(raw).image; } catch { /* handled below */ }
  if (!image || typeof image !== 'string') return send(res, 400, { error: { code: 'http', message: 'No image received.' } });
  try {
    const r = await fetch(`${API}/${MODEL}:generateContent`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': KEY },
      body: JSON.stringify({ contents: [{ parts: [{ text: PROMPT }, { inline_data: { mime_type: 'image/jpeg', data: image } }] }], generationConfig: { temperature: 0.3, maxOutputTokens: 400 } })
    });
    const body = await r.json().catch(() => null);
    if (!r.ok) return send(res, 502, { error: mapError(r.status, body) });
    const text = body?.candidates?.[0]?.content?.parts?.map(p => p.text).join(' ').trim();
    if (!text) return send(res, 502, { error: { code: 'http', message: 'Gemini returned an empty answer.' } });
    send(res, 200, { text });
  } catch { send(res, 502, { error: { code: 'network', message: 'Server could not reach Google.' } }); }
}

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x'), ip = req.headers['x-forwarded-for']?.split(',')[0] || req.socket.remoteAddress;
  if (url.pathname.startsWith('/api/')) {
    if (req.method === 'OPTIONS') { res.writeHead(204, CORS); return res.end(); }
    if (limited(ip)) return send(res, 429, { error: { code: 'quota', message: 'Too many requests. Please wait a minute.' } });
    if (url.pathname === '/api/status' && req.method === 'GET') return status(res);
    if (url.pathname === '/api/describe' && req.method === 'POST') return describe(req, res);
    return send(res, 404, { error: { code: 'http', message: 'Not found.' } });
  }
  const rel = normalize(url.pathname === '/' ? '/index.html' : url.pathname).replace(/^(\.\.[/\\])+/, '');
  try {
    const file = await readFile(join(ROOT, rel));
    res.writeHead(200, { 'Content-Type': TYPES[extname(rel)] || 'application/octet-stream', 'Permissions-Policy': 'camera=(self), microphone=(self), geolocation=(self), bluetooth=(self)' });
    res.end(file);
  } catch { res.writeHead(404); res.end('Not found'); }
}).listen(process.env.PORT || 8080, () => console.log(`Saathi AI on :${process.env.PORT || 8080} | Gemini key ${KEY ? 'set' : 'MISSING'}`));
